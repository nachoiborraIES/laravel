<?php

function fechaActual($formato)
{
    return date($formato);
}