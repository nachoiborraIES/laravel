@extends('plantilla')

@section('titulo', 'Ficha post')

@section('contenido')
    <h1>Ficha del post {{ $post->id }}</h1>
    <p>Título: {{ $post->titulo }}</p>
    <p><em>Creado en {{ $post->created_at }}</em></p>
    {{ $post->contenido }}
@endsection
