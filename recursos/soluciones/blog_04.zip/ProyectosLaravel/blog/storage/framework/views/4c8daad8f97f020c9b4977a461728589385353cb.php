<?php $__env->startSection('titulo', 'Ficha post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha del post <?php echo e($post->id); ?></h1>
    <p>Título: <?php echo e($post->titulo); ?></p>
    <p><em>Creado en <?php echo e($post->created_at); ?></em></p>
    <?php echo e($post->contenido); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/ProyectosLaravel/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>