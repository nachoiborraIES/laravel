<?php $__env->startSection('titulo', 'Listado posts'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Listado de posts</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/ProyectosLaravel/blog/resources/views/posts/listado.blade.php ENDPATH**/ ?>