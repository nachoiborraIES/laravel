<?php $__env->startSection('titulo', 'Ficha de libro'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha de libro <?php echo e($libro->id); ?></h1>
    <p>Título: <?php echo e($libro->titulo); ?></p>
    <p>Editorial: <?php echo e($libro->editorial); ?></p>
    <p>Precio: <?php echo e($libro->precio); ?></p>
    <p>Autor: <?php echo e($libro->autor->nombre); ?> (<?php echo e($libro->autor->nacimiento); ?>)</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/ProyectosLaravel/biblioteca/resources/views/libros/show.blade.php ENDPATH**/ ?>