<?php $__env->startSection('titulo', 'Ficha de libro'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha de libro <?php echo e($id); ?></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/ProyectosLaravel/biblioteca/resources/views/libros/show.blade.php ENDPATH**/ ?>