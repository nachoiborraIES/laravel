<?php $__env->startSection('titulo', "Inicio"); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Página de inicio</h1>
    <p>Bienvenido/a, <?php echo e($nombre); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/ProyectosLaravel/biblioteca/resources/views/inicio.blade.php ENDPATH**/ ?>