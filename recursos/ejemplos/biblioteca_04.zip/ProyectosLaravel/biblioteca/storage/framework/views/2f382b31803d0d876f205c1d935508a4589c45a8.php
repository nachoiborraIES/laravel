<!DOCTYPE html>
<html>
    <head>
        <title>Listado de libros</title>
    </head>
    <body>
        <h1>Listado de libros</h1>
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li><?php echo e($libro["titulo"]); ?> (<?php echo e($libro["autor"]); ?>)</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No se encontraron libros</li>
            <?php endif; ?>
        </ul>
    </body>
</html>
<?php /**PATH /home/alumno/ProyectosLaravel/biblioteca/resources/views/listado.blade.php ENDPATH**/ ?>