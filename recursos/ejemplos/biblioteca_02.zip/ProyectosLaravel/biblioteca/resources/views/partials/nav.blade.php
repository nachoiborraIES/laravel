<nav>
    <a href="{{ route('inicio') }}">Inicio</a>
    &nbsp;&nbsp;
    <a href="{{ route('listado_libros') }}">Listado de libros</a>
</nav>
