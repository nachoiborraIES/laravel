<nav>
    <a href="<?php echo e(route('inicio')); ?>">Inicio</a>
    &nbsp;&nbsp;
    <a href="<?php echo e(route('listado_libros')); ?>">Listado de libros</a>
</nav>
<?php /**PATH /home/alumno/ProyectosLaravel/biblioteca/resources/views/partials/nav.blade.php ENDPATH**/ ?>